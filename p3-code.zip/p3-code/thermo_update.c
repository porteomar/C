// #include <stdio.h>
// #include "thermo.h"

// int thermo_update(){
//    temp_t temp = {
//     //    .tenths_degrees = 0,
//     //    .is_fahrenheit = 0
//    };
//    int display = THERMO_DISPLAY_PORT;
        
//    if(set_temp_from_ports(&temp) == 1){
//        return 0;
//     }
//     if(set_display_from_temp(temp, &display) == 1){
//            return 0;
//     } 
//     set_temp_from_ports(&temp); 
//     set_display_from_temp(temp, &display);
//     THERMO_DISPLAY_PORT = display;

//    return 0;
// }
   
// int set_temp_from_ports(temp_t *temp){
//     int sensorPortVal = ((THERMO_SENSOR_PORT/64) - 500);
//     int forF = THERMO_STATUS_PORT & (1);
//     int remainder = THERMO_SENSOR_PORT % 64;

//     if(sensorPortVal > 500){
//         return 1;
//     }

//     if (remainder > 31){
//         sensorPortVal += 1;
//     }

//     if(!forF){
//         temp->tenths_degrees = sensorPortVal;
//         temp->is_fahrenheit = 0;
//     }
//     else if(forF){
//         temp->tenths_degrees = (sensorPortVal * 9) / 5 + 320;
//         temp->is_fahrenheit = 1;
//     }
    
//     return 0;
// }

// int set_display_from_temp(temp_t temp, int *display){
//     int tempT = temp.tenths_degrees;
//     int maskArray[12] = {0b1111110, 0b0001100, 0b0110111, 0b0011111, 0b1001101, 
//                          0b1011011, 0b1111011, 0b0001110, 0b1111111, 0b1011111,
//                          0b0000000, 0b0000001};

//     if(temp.is_fahrenheit == 1){
//         if ((tempT < -580) || (tempT >  1220)){

//             return 1;
//         }
//     }

//     if (temp.is_fahrenheit == 0) {
    
//         if ((tempT < -500) || (tempT > 500)){

//             return 1;
//         } 
//     }
    
//     if (temp.is_fahrenheit != 0 && temp.is_fahrenheit != 1){

//         return 1;    
//     }
//         *display = 0x0;
//         if(tempT < 0){
//             tempT = tempT/-1; 
//             *display = *display | (maskArray[11]);
//             *display = *display << 7;
//         }

//         int tenths = tempT % 10;
//         tempT = tempT/10;

//         int ones = tempT % 10;
//         tempT = tempT/10;

//         int tens = tempT % 10;
//         tempT = tempT/10;

//         int hunds = tempT % 10;

//         if(hunds != 0){
//             *display = *display | (maskArray[hunds]);
//             *display = *display << 7;        
//         }
//         if(hunds != 0 || tens != 0){
//             *display = *display | (maskArray[tens]);
//             *display = *display << 7;        
//         }

//         *display = *display | (maskArray[ones]);
//         *display = *display << 7;
//         *display = *display | maskArray[tenths];

//         if (temp.is_fahrenheit == 1){
//             *display = *display | (1 << 29);
//         }
//             if (temp.is_fahrenheit == 0){
//                 *display = *display | (1 << 28);
//         }
    
//    return 0;
// }
